   W: Go Forward
   S: Go Backward
   direction arrows: rotate model
   F11: Solid fill mode
   F12: Wire Frame fill mode